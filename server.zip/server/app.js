const express = require("express");
const cors = require("cors");
const helmet = require("helmet");
const morgan = require("morgan");
const cookieParser = require("cookie-parser");
const path = require("path");
const http = require("http");
const jwt = require("jsonwebtoken");
const fileRoutes = require("./routes/fileRoutes");
const {
  Server,
} = require("socket.io");

require("dotenv").config();

const pool = require("./config/db");

// ==========================================
// ROUTES
// ==========================================

const authRoutes = require(
  "./routes/authRoutes"
);

const dashboardRoutes = require(
  "./routes/dashboardRoutes"
);

const employeeRoutes = require(
  "./routes/employeeRoutes"
);

const attendanceRoutes = require(
  "./routes/attendanceRoutes"
);

const taskRoutes = require(
  "./routes/taskRoutes"
);
const taskManagementRoutes = require(
  "./routes/taskManagementRoutes"
);
console.log(taskManagementRoutes);
console.log(typeof taskManagementRoutes);

const leaveRoutes = require(
  "./routes/leaveRoutes"
);

const reportRoutes = require(
  "./routes/reportRoutes"
);

const notificationRoutes = require(
  "./routes/notificationRoutes"
);

const chatRoutes = require(
  "./routes/chatRoutes"
);

// ==========================================
// APP + HTTP SERVER
// ==========================================

const app = express();

const server = http.createServer(
  app
);

const PORT =
  process.env.PORT || 5000;

// ==========================================
// SOCKET.IO SERVER
// ==========================================

const io = new Server(
  server,
  {
    cors: {
origin: [
  "http://localhost:5173",
  "http://localhost:5174",
],
      methods: [
        "GET",
        "POST",
      ],

      credentials: true,
    },
  }
);

// ==========================================
// TRACK ONLINE USERS
//
// Map:
//
// userId => Set(socketId)
//
// Supports multiple browser tabs/devices.
// ==========================================

const onlineUsers =
  new Map();

// ==========================================
// SOCKET AUTHENTICATION
// ==========================================

io.use(
  async (
    socket,
    next
  ) => {
    try {
      const token =
        socket.handshake.auth
          ?.token;

      if (!token) {
        return next(
          new Error(
            "Authentication token required"
          )
        );
      }

      const decoded =
        jwt.verify(
          token,
          process.env.JWT_SECRET
        );

      // ======================================
      // VERIFY USER
      // ======================================

      const [users] =
        await pool.query(
          `
          SELECT
            id,
            employee_id,
            full_name,
            role,
            status
          FROM users
          WHERE id = ?
          LIMIT 1
          `,
          [
            decoded.id,
          ]
        );

      if (
        users.length === 0
      ) {
        return next(
          new Error(
            "User not found"
          )
        );
      }

      const user =
        users[0];

      if (
        user.status !==
        "active"
      ) {
        return next(
          new Error(
            "User account is not active"
          )
        );
      }

      // ======================================
      // STORE AUTHENTICATED USER ON SOCKET
      // ======================================

      socket.user = {
        id:
          user.id,

        employeeId:
          user.employee_id,

        fullName:
          user.full_name,

        role:
          user.role,
      };

      next();

    } catch (error) {
      console.error(
        "Socket authentication error:",
        error.message
      );

      next(
        new Error(
          "Invalid or expired authentication token"
        )
      );
    }
  }
);

// ==========================================
// SOCKET CONNECTION
// ==========================================

io.on(
  "connection",
  (socket) => {
    const userId =
      String(
        socket.user.id
      );

    console.log(
      `Socket connected: ${socket.user.fullName} (${userId})`
    );

    // ========================================
    // JOIN PERSONAL USER ROOM
    //
    // Used for:
    // - Direct notifications
    // - Chat notifications
    // - Calls
    // - WebRTC signaling
    // ========================================

    socket.join(
      `user:${userId}`
    );

    // ========================================
    // TRACK USER CONNECTION
    // ========================================

    if (
      !onlineUsers.has(
        userId
      )
    ) {
      onlineUsers.set(
        userId,
        new Set()
      );
    }

    onlineUsers
      .get(userId)
      .add(
        socket.id
      );

    // ========================================
    // ANNOUNCE USER ONLINE
    // ========================================

    io.emit(
      "user:online",
      {
        userId:
          Number(userId),
      }
    );

    // ========================================
    // SEND CURRENT ONLINE USERS
    // ========================================

    socket.emit(
      "users:online",
      Array.from(
        onlineUsers.keys()
      ).map(
        (id) =>
          Number(id)
      )
    );

    // ========================================
    // JOIN CONVERSATION ROOM
    // ========================================

    socket.on(
      "conversation:join",
      async (
        conversationId
      ) => {
        try {
          const id =
            Number(
              conversationId
            );

          if (
            !Number.isInteger(
              id
            ) ||
            id <= 0
          ) {
            return;
          }

          // Security:
          // User must belong to conversation.

          const [members] =
            await pool.query(
              `
              SELECT id
              FROM conversation_members
              WHERE conversation_id = ?
              AND user_id = ?
              LIMIT 1
              `,
              [
                id,
                socket.user.id,
              ]
            );

          if (
            members.length === 0
          ) {
            console.warn(
              `Unauthorized conversation join attempt by user ${userId}`
            );

            return;
          }

          socket.join(
            `conversation:${id}`
          );

        } catch (error) {
          console.error(
            "Conversation join error:",
            error
          );
        }
      }
    );

    // ========================================
    // LEAVE CONVERSATION ROOM
    // ========================================

    socket.on(
      "conversation:leave",
      (
        conversationId
      ) => {
        const id =
          Number(
            conversationId
          );

        if (
          !Number.isInteger(
            id
          ) ||
          id <= 0
        ) {
          return;
        }

        socket.leave(
          `conversation:${id}`
        );
      }
    );

    // ========================================
    // CALL HELPER
    //
    // Verify target user exists and is active.
    // ========================================

    const verifyCallTarget =
      async (
        targetUserId
      ) => {
        const targetId =
          Number(
            targetUserId
          );

        if (
          !Number.isInteger(
            targetId
          ) ||
          targetId <= 0
        ) {
          return null;
        }

        // Prevent calling yourself.

        if (
          targetId ===
          Number(
            socket.user.id
          )
        ) {
          return null;
        }

        const [users] =
          await pool.query(
            `
            SELECT
              id,
              employee_id,
              full_name,
              role,
              status
            FROM users
            WHERE id = ?
            AND status = 'active'
            LIMIT 1
            `,
            [
              targetId,
            ]
          );

        if (
          users.length === 0
        ) {
          return null;
        }

        return users[0];
      };

    // ========================================
    // START CALL
    //
    // callType:
    // "audio" or "video"
    // ========================================

    socket.on(
      "call:start",
      async (
        data = {}
      ) => {
        try {
          const {
            targetUserId,
            callType,
          } = data;

          const targetUser =
            await verifyCallTarget(
              targetUserId
            );

          if (
            !targetUser
          ) {
            socket.emit(
              "call:error",
              {
                message:
                  "Unable to call this user",
              }
            );

            return;
          }

          if (
            callType !==
              "audio" &&
            callType !==
              "video"
          ) {
            socket.emit(
              "call:error",
              {
                message:
                  "Invalid call type",
              }
            );

            return;
          }

          const targetId =
            String(
              targetUser.id
            );

          // ====================================
          // CHECK IF USER IS ONLINE
          // ====================================

          if (
            !onlineUsers.has(
              targetId
            )
          ) {
            socket.emit(
              "call:unavailable",
              {
                targetUserId:
                  targetUser.id,

                message:
                  "User is currently offline",
              }
            );

            return;
          }

          // ====================================
          // SEND INCOMING CALL
          // ====================================

          io
            .to(
              `user:${targetId}`
            )
            .emit(
              "call:incoming",
              {
                callerId:
                  Number(
                    socket.user.id
                  ),

                callerEmployeeId:
                  socket.user
                    .employeeId,

                callerName:
                  socket.user
                    .fullName,

                callerRole:
                  socket.user
                    .role,

                callType,
              }
            );

          // ====================================
          // CONFIRM TO CALLER
          // ====================================

          socket.emit(
            "call:ringing",
            {
              targetUserId:
                targetUser.id,

              targetEmployeeId:
                targetUser
                  .employee_id,

              targetName:
                targetUser
                  .full_name,

              callType,
            }
          );

        } catch (error) {
          console.error(
            "Start call error:",
            error
          );

          socket.emit(
            "call:error",
            {
              message:
                "Unable to start call",
            }
          );
        }
      }
    );

    // ========================================
    // ACCEPT CALL
    // ========================================

    socket.on(
      "call:accept",
      async (
        data = {}
      ) => {
        try {
          const {
            callerId,
            callType,
          } = data;

          const caller =
            await verifyCallTarget(
              callerId
            );

          if (
            !caller
          ) {
            return;
          }

          io
            .to(
              `user:${caller.id}`
            )
            .emit(
              "call:accepted",
              {
                userId:
                  Number(
                    socket.user.id
                  ),

                employeeId:
                  socket.user
                    .employeeId,

                fullName:
                  socket.user
                    .fullName,

                callType:
                  callType ===
                  "video"
                    ? "video"
                    : "audio",
              }
            );

        } catch (error) {
          console.error(
            "Accept call error:",
            error
          );
        }
      }
    );

    // ========================================
    // REJECT CALL
    // ========================================

    socket.on(
      "call:reject",
      async (
        data = {}
      ) => {
        try {
          const {
            callerId,
          } = data;

          const caller =
            await verifyCallTarget(
              callerId
            );

          if (
            !caller
          ) {
            return;
          }

          io
            .to(
              `user:${caller.id}`
            )
            .emit(
              "call:rejected",
              {
                userId:
                  Number(
                    socket.user.id
                  ),

                fullName:
                  socket.user
                    .fullName,
              }
            );

        } catch (error) {
          console.error(
            "Reject call error:",
            error
          );
        }
      }
    );

    // ========================================
    // END CALL
    // ========================================

    socket.on(
      "call:end",
      async (
        data = {}
      ) => {
        try {
          const {
            targetUserId,
          } = data;

          const targetUser =
            await verifyCallTarget(
              targetUserId
            );

          if (
            !targetUser
          ) {
            return;
          }

          io
            .to(
              `user:${targetUser.id}`
            )
            .emit(
              "call:ended",
              {
                userId:
                  Number(
                    socket.user.id
                  ),

                fullName:
                  socket.user
                    .fullName,
              }
            );

        } catch (error) {
          console.error(
            "End call error:",
            error
          );
        }
      }
    );

    // ========================================
    // WEBRTC OFFER
    // ========================================

    socket.on(
      "webrtc:offer",
      async (
        data = {}
      ) => {
        try {
          const {
            targetUserId,
            offer,
          } = data;

          const targetUser =
            await verifyCallTarget(
              targetUserId
            );

          if (
            !targetUser ||
            !offer
          ) {
            return;
          }

          io
            .to(
              `user:${targetUser.id}`
            )
            .emit(
              "webrtc:offer",
              {
                fromUserId:
                  Number(
                    socket.user.id
                  ),

                offer,
              }
            );

        } catch (error) {
          console.error(
            "WebRTC offer error:",
            error
          );
        }
      }
    );

    // ========================================
    // WEBRTC ANSWER
    // ========================================

    socket.on(
      "webrtc:answer",
      async (
        data = {}
      ) => {
        try {
          const {
            targetUserId,
            answer,
          } = data;

          const targetUser =
            await verifyCallTarget(
              targetUserId
            );

          if (
            !targetUser ||
            !answer
          ) {
            return;
          }

          io
            .to(
              `user:${targetUser.id}`
            )
            .emit(
              "webrtc:answer",
              {
                fromUserId:
                  Number(
                    socket.user.id
                  ),

                answer,
              }
            );

        } catch (error) {
          console.error(
            "WebRTC answer error:",
            error
          );
        }
      }
    );



    // ========================================
    // WEBRTC ICE CANDIDATE
    // ========================================

    socket.on(
      "webrtc:ice-candidate",
      async (
        data = {}
      ) => {
        try {
          const {
            targetUserId,
            candidate,
          } = data;

          const targetUser =
            await verifyCallTarget(
              targetUserId
            );

          if (
            !targetUser ||
            !candidate
          ) {
            return;
          }

          io
            .to(
              `user:${targetUser.id}`
            )
            .emit(
              "webrtc:ice-candidate",
              {
                fromUserId:
                  Number(
                    socket.user.id
                  ),

                candidate,
              }
            );

        } catch (error) {
          console.error(
            "WebRTC ICE candidate error:",
            error
          );
        }
      }
    );

    // ========================================
    // DISCONNECT
    // ========================================

    socket.on(
      "disconnect",
      () => {
        console.log(
          `Socket disconnected: ${socket.user.fullName} (${userId})`
        );

        const userSockets =
          onlineUsers.get(
            userId
          );

        if (
          userSockets
        ) {
          userSockets.delete(
            socket.id
          );

          // Only mark offline when
          // ALL tabs/devices disconnect.

          if (
            userSockets.size ===
            0
          ) {
            onlineUsers.delete(
              userId
            );

            io.emit(
              "user:offline",
              {
                userId:
                  Number(
                    userId
                  ),
              }
            );
          }
        }
      }
    );
  }
);

// ==========================================
// MAKE SOCKET.IO AVAILABLE TO ROUTES
// ==========================================

app.set(
  "io",
  io
);

app.set(
  "onlineUsers",
  onlineUsers
);

// ==========================================
// SECURITY MIDDLEWARE
// ==========================================

app.use(
  helmet({
    crossOriginResourcePolicy: {
      policy:
        "cross-origin",
    },
  })
);

// ==========================================
// CORS CONFIGURATION
// ==========================================

app.use(
  cors({
origin: [
  "http://localhost:5173",
  "http://localhost:5174",
],

    credentials:
      true,

    methods: [
      "GET",
      "POST",
      "PUT",
      "PATCH",
      "DELETE",
      "OPTIONS",
    ],

    allowedHeaders: [
      "Content-Type",
      "Authorization",
    ],
  })
);

// ==========================================
// GENERAL MIDDLEWARE
// ==========================================

app.use(
  express.json()
);

app.use(
  express.urlencoded({
    extended: true,
  })
);

app.use(
  cookieParser()
);

app.use(
  morgan("dev")
);

// ==========================================
// SERVE UPLOADED FILES
// ==========================================

app.use(
  "/uploads",
  express.static(
    path.join(
      __dirname,
      "uploads"
    )
  )
);

// ==========================================
// MAIN TEST ROUTE
// ==========================================

app.get(
  "/",
  (
    req,
    res
  ) => {
    return res
      .status(200)
      .json({
        success: true,

        message:
          "Reinsteins WorkHub Backend is running",
      });
  }
);

// ==========================================
// DATABASE TEST ROUTE
// ==========================================

app.get(
  "/api/db-test",
  async (
    req,
    res
  ) => {
    try {
      const [rows] =
        await pool.query(
          "SELECT DATABASE() AS databaseName"
        );

      return res
        .status(200)
        .json({
          success: true,

          message:
            "MySQL connected successfully",

          database:
            rows[0]
              .databaseName,
        });

    } catch (error) {
      console.error(
        "Database connection error:",
        error
      );

      return res
        .status(500)
        .json({
          success: false,

          message:
            "MySQL connection failed",

          error:
            error.message,
        });
    }
  }
);
    // TASKS

app.use(
  "/api/tasks",
  taskRoutes
);
console.log("Registering task-management routes");
app.get("/api/task-management/test", (req, res) => {
  return res.json({
    success: true,
    message: "App.js route works"
  });
});
console.log("Task-management routes registered");

// ==========================================
// API ROUTES
// ==========================================

// AUTH

app.use(
  "/api/auth",
  authRoutes
);
app.use("/api/files", fileRoutes);
// DASHBOARD

app.use(
  "/api/dashboard",
  dashboardRoutes
);

// EMPLOYEES + PROFILE

app.use(
  "/api/employees",
  employeeRoutes
);

// ATTENDANCE

app.use(
  "/api/attendance",
  attendanceRoutes
);



// LEAVE

app.use(
  "/api/leaves",
  leaveRoutes
);

// REPORTS

app.use(
  "/api/reports",
  reportRoutes
);

// NOTIFICATIONS

app.use(
  "/api/notifications",
  notificationRoutes
);

// CHAT

app.use(
  "/api/chat",
  chatRoutes
);

// ==========================================
// 404 ROUTE
// KEEP AFTER ALL API ROUTES
// ==========================================

app.use(
  (
    req,
    res
  ) => {
    return res
      .status(404)
      .json({
        success: false,

        message:
          "API route not found",
      });
  }
);

// ==========================================
// START HTTP + SOCKET.IO SERVER
// ==========================================

server.listen(
  PORT,
  () => {
    console.log(
      "-------------------------------------------"
    );

    console.log(
      "Reinsteins WorkHub Backend"
    );

    console.log(
      `Server running on http://localhost:${PORT}`
    );

    console.log(
      "Socket.IO real-time server is running"
    );

    console.log(
      "WebRTC call signaling is enabled"
    );

    console.log(
      "Profile photos available at /uploads/profiles/"
    );

    console.log(
      "Reports API available at /api/reports/"
    );

    console.log(
      "Notifications API available at /api/notifications/"
    );

    console.log(
      "-------------------------------------------"
    );
  }
);