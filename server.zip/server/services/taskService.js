const pool = require("../config/db");

// ==========================================
// GET ACTIVE EMPLOYEES
// ==========================================

const getActiveEmployees = async () => {

    const [employees] = await pool.query(`
        SELECT
            id,
            employee_id,
            full_name,
            role
        FROM users
        WHERE status='active'
        ORDER BY full_name
    `);

    return employees;

};

// ==========================================
// GET ALL TASKS
// ==========================================

const getAllTasks = async () => {

    const [tasks] = await pool.query(`

        SELECT

            t.*,

            u1.full_name AS assigned_to_name,

            u2.full_name AS assigned_by_name

        FROM tasks t

        LEFT JOIN users u1
            ON u1.id = t.assigned_to

        LEFT JOIN users u2
            ON u2.id = t.assigned_by

        ORDER BY t.id DESC

    `);

    return tasks;

};

// ==========================================
// CREATE TASK
// ==========================================

const createTask = async (data) => {

    const {

        title,

        description,

        assigned_to,

        assigned_by,

        priority,

        status,

        due_date,

        estimated_hours,

        tags

    } = data;

    const [[lastTask]] = await pool.query(`
        SELECT id
        FROM tasks
        ORDER BY id DESC
        LIMIT 1
    `);

    const next = (lastTask?.id || 0) + 1;

    const taskNumber =
        "RT-" + String(next).padStart(4, "0");

    await pool.query(

        `
        INSERT INTO tasks(

            task_number,

            user_id,

            assigned_to,

            assigned_by,

            task_title,

            task_description,

            priority,

            status,

            due_date,

            estimated_hours,

            tags,

            progress

        )

        VALUES(

            ?,?,?,?,?,?,?,?,?,?,?,?

        )
        `,

        [

            taskNumber,

            assigned_by,

            assigned_to,

            assigned_by,

            title,

            description,

            priority,

            status,

            due_date || null,

            estimated_hours || null,

            tags || null,

            0

        ]

    );

};

module.exports = {

    getActiveEmployees,

    getAllTasks,

    createTask

};