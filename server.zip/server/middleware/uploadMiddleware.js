const multer = require("multer");
const path = require("path");
const fs = require("fs");

// ==========================================
// PROFILE UPLOAD DIRECTORY
// ==========================================

const uploadDirectory = path.join(
  __dirname,
  "../uploads/profiles"
);

// Create folder automatically if missing
if (!fs.existsSync(uploadDirectory)) {
  fs.mkdirSync(uploadDirectory, {
    recursive: true,
  });
}

// ==========================================
// STORAGE CONFIGURATION
// ==========================================

const storage = multer.diskStorage({
  destination: (
    req,
    file,
    callback
  ) => {
    callback(
      null,
      uploadDirectory
    );
  },

  filename: (
    req,
    file,
    callback
  ) => {
    const extension =
      path.extname(
        file.originalname
      ).toLowerCase();

    const uniqueName =
      `employee-${req.user.id}-${Date.now()}${extension}`;

    callback(
      null,
      uniqueName
    );
  },
});

// ==========================================
// FILE FILTER
// ==========================================

const fileFilter = (
  req,
  file,
  callback
) => {
  const allowedMimeTypes = [
    "image/jpeg",
    "image/png",
    "image/webp",
  ];

  if (
    allowedMimeTypes.includes(
      file.mimetype
    )
  ) {
    callback(
      null,
      true
    );
  } else {
    callback(
      new Error(
        "Only JPG, JPEG, PNG and WEBP images are allowed"
      ),
      false
    );
  }
};

// ==========================================
// MULTER CONFIGURATION
// Maximum profile photo size: 5 MB
// ==========================================

const uploadProfilePhoto =
  multer({
    storage,

    fileFilter,

    limits: {
      fileSize:
        5 * 1024 * 1024,
    },
  });

// ==========================================
// EXPORT
// ==========================================

module.exports = {
  uploadProfilePhoto,
};