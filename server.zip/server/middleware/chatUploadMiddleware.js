const multer = require("multer");
const path = require("path");
const fs = require("fs");

// ==========================================
// CREATE UPLOAD DIRECTORIES
// ==========================================

const imageDirectory = path.join(
  __dirname,
  "../uploads/chat/images"
);

const fileDirectory = path.join(
  __dirname,
  "../uploads/chat/files"
);

if (!fs.existsSync(imageDirectory)) {
  fs.mkdirSync(imageDirectory, {
    recursive: true,
  });
}

if (!fs.existsSync(fileDirectory)) {
  fs.mkdirSync(fileDirectory, {
    recursive: true,
  });
}

// ==========================================
// STORAGE
// ==========================================

const storage = multer.diskStorage({
  destination(req, file, callback) {
    if (file.mimetype.startsWith("image/")) {
      callback(null, imageDirectory);
    } else {
      callback(null, fileDirectory);
    }
  },

  filename(req, file, callback) {
    const extension = path.extname(file.originalname);

    callback(
      null,
      `chat-${Date.now()}-${Math.round(
        Math.random() * 1000000
      )}${extension}`
    );
  },
});

// ==========================================
// ALLOWED FILE TYPES
// ==========================================

const allowedTypes = [
  // Images
  "image/jpeg",
  "image/jpg",
  "image/png",
  "image/webp",
  "image/gif",

  // PDF
  "application/pdf",

  // Word
  "application/msword",
  "application/vnd.openxmlformats-officedocument.wordprocessingml.document",

  // Excel
  "application/vnd.ms-excel",
  "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",

  // PowerPoint
  "application/vnd.ms-powerpoint",
  "application/vnd.openxmlformats-officedocument.presentationml.presentation",

  // Text
  "text/plain",

  // Zip
  "application/zip",
  "application/x-zip-compressed",
  "application/x-rar-compressed",
];

const fileFilter = (req, file, callback) => {
  if (allowedTypes.includes(file.mimetype)) {
    callback(null, true);
  } else {
    callback(
      new Error("Unsupported file type."),
      false
    );
  }
};

// ==========================================
// EXPORT
// ==========================================

module.exports = multer({
  storage,
  fileFilter,
  limits: {
    fileSize: 50 * 1024 * 1024,
  },
});