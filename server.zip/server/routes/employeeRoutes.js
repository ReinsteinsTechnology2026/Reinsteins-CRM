const express = require("express");

const {
  getEmployees,
  createEmployee,
  updateEmployee,
  changeEmployeeStatus,
  getMyProfile,
  updateMyProfile,
  uploadMyProfilePhoto,
} = require(
  "../controllers/employeeController"
);

const {
  protect,
  adminOnly,
} = require(
  "../middleware/authMiddleware"
);

const {
  uploadProfilePhoto,
} = require(
  "../middleware/uploadMiddleware"
);

const router = express.Router();

// ==========================================
// EMPLOYEE - GET MY PROFILE
// ==========================================

router.get(
  "/profile/me",
  protect,
  getMyProfile
);

// ==========================================
// EMPLOYEE - UPDATE MY PROFILE
// ==========================================

router.put(
  "/profile/me",
  protect,
  updateMyProfile
);

// ==========================================
// EMPLOYEE - UPLOAD PROFILE PHOTO
// Field name must be: profilePhoto
// ==========================================

router.post(
  "/profile/photo",
  protect,
  uploadProfilePhoto.single(
    "profilePhoto"
  ),
  uploadMyProfilePhoto
);

// ==========================================
// ADMIN - GET ALL EMPLOYEES
// ==========================================

router.get(
  "/",
  protect,
  adminOnly,
  getEmployees
);

// ==========================================
// ADMIN - CREATE EMPLOYEE
// ==========================================

router.post(
  "/",
  protect,
  adminOnly,
  createEmployee
);

// ==========================================
// ADMIN - UPDATE EMPLOYEE
// ==========================================

router.put(
  "/:id",
  protect,
  adminOnly,
  updateEmployee
);

// ==========================================
// ADMIN - CHANGE EMPLOYEE STATUS
// ==========================================

router.patch(
  "/:id/status",
  protect,
  adminOnly,
  changeEmployeeStatus
);

module.exports = router;