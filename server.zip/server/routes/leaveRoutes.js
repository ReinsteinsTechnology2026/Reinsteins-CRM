const express =
  require("express");

const {
  applyLeave,
  getMyLeaves,
  getAllLeaves,
  approveLeave,
  rejectLeave,
} = require(
  "../controllers/leaveController"
);

const {
  protect,
  adminOnly,
} = require(
  "../middleware/authMiddleware"
);

const router =
  express.Router();

// ==========================================
// ADMIN - GET ALL LEAVE REQUESTS
// ==========================================

router.get(
  "/admin/all",
  protect,
  adminOnly,
  getAllLeaves
);

// ==========================================
// ADMIN - APPROVE LEAVE
// ==========================================

router.patch(
  "/admin/:id/approve",
  protect,
  adminOnly,
  approveLeave
);

// ==========================================
// ADMIN - REJECT LEAVE
// ==========================================

router.patch(
  "/admin/:id/reject",
  protect,
  adminOnly,
  rejectLeave
);

// ==========================================
// EMPLOYEE - GET MY LEAVE REQUESTS
// ==========================================

router.get(
  "/my",
  protect,
  getMyLeaves
);

// ==========================================
// EMPLOYEE - APPLY FOR LEAVE
// ==========================================

router.post(
  "/",
  protect,
  applyLeave
);

module.exports = router;