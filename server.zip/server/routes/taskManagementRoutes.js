console.log("✅ taskManagementRoutes loaded");
const express = require("express");


const router = express.Router();

const {

    getEmployees,

    getTasks,

    createTask

} = require("../controllers/taskManagementController");

const {

    protect

} = require("../middleware/authMiddleware");

router.get(
    "/employees",
    protect,
    getEmployees
);

router.get(
    "/tasks",
    protect,
    getTasks
);

router.post(
    "/create",
    protect,
    createTask
);
router.get("/test", (req, res) => {
    res.json({
        success: true,
        message: "Task Management Route Working"
    });
});

module.exports = router;