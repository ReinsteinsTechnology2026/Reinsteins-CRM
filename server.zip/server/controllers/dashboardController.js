const pool = require("../config/db");

const getDashboardStats = async (req, res) => {
  try {
    // ==========================================
    // TOTAL ACTIVE EMPLOYEES
    // ==========================================

    const [employeeResult] = await pool.query(
      `
      SELECT COUNT(*) AS totalEmployees
      FROM users
      WHERE role = 'employee'
      AND status = 'active'
      `
    );

    // ==========================================
    // PRESENT TODAY
    // Employees who logged attendance today
    // ==========================================

    const [presentResult] = await pool.query(
      `
      SELECT COUNT(DISTINCT user_id) AS presentToday
      FROM attendance
      WHERE DATE(login_time) = CURDATE()
      `
    );

    // ==========================================
    // EMPLOYEES ON APPROVED LEAVE TODAY
    // ==========================================

    const [onLeaveResult] = await pool.query(
      `
      SELECT COUNT(DISTINCT user_id) AS onLeave
      FROM leave_requests
      WHERE status = 'approved'
      AND CURDATE() BETWEEN from_date AND to_date
      `
    );

    // ==========================================
    // ACTIVE TASKS
    // ==========================================

    const [activeTaskResult] = await pool.query(
      `
      SELECT COUNT(*) AS activeTasks
      FROM tasks
      WHERE status = 'in_progress'
      `
    );

    // ==========================================
    // RECENT EMPLOYEES
    // ==========================================

    const [recentEmployees] = await pool.query(
      `
      SELECT
        id,
        employee_id,
        full_name,
        email,
        status,
        created_at
      FROM users
      WHERE role = 'employee'
      ORDER BY created_at DESC
      LIMIT 5
      `
    );

    // ==========================================
    // SEND DASHBOARD DATA
    // ==========================================

    return res.status(200).json({
      success: true,

      stats: {
        totalEmployees:
          employeeResult[0].totalEmployees,

        presentToday:
          presentResult[0].presentToday,

        onLeave:
          onLeaveResult[0].onLeave,

        activeTasks:
          activeTaskResult[0].activeTasks,
      },

      recentEmployees,
    });

  } catch (error) {
    console.error(
      "Dashboard Stats Error:",
      error
    );

    return res.status(500).json({
      success: false,
      message:
        "Unable to load dashboard statistics",
    });
  }
};

module.exports = {
  getDashboardStats,
};