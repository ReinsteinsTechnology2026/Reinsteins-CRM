const pool = require("../config/db");

// ==========================================
// EMPLOYEE - APPLY FOR LEAVE
// ==========================================

const applyLeave = async (req, res) => {
  try {
    const userId = req.user.id;

    const {
      leaveType,
      fromDate,
      toDate,
      reason,
    } = req.body;

    if (
      !leaveType ||
      !fromDate ||
      !toDate ||
      !reason?.trim()
    ) {
      return res.status(400).json({
        success: false,
        message:
          "Leave type, dates and reason are required",
      });
    }

    if (
      new Date(toDate) <
      new Date(fromDate)
    ) {
      return res.status(400).json({
        success: false,
        message:
          "To date cannot be before from date",
      });
    }

    // ========================================
    // CHECK OVERLAPPING LEAVE REQUESTS
    // ========================================

    const [existingLeaves] =
      await pool.query(
        `
        SELECT id
        FROM leave_requests
        WHERE user_id = ?
        AND status IN (
          'pending',
          'approved'
        )
        AND from_date <= ?
        AND to_date >= ?
        LIMIT 1
        `,
        [
          userId,
          toDate,
          fromDate,
        ]
      );

    if (
      existingLeaves.length > 0
    ) {
      return res.status(400).json({
        success: false,
        message:
          "You already have a pending or approved leave request for these dates",
      });
    }

    // ========================================
    // CREATE LEAVE REQUEST
    // ========================================

    const [result] =
      await pool.query(
        `
        INSERT INTO leave_requests
        (
          user_id,
          leave_type,
          from_date,
          to_date,
          reason,
          status
        )
        VALUES
        (
          ?,
          ?,
          ?,
          ?,
          ?,
          'pending'
        )
        `,
        [
          userId,
          leaveType,
          fromDate,
          toDate,
          reason.trim(),
        ]
      );

    return res.status(201).json({
      success: true,

      message:
        "Leave request submitted successfully",

      leaveId:
        result.insertId,
    });
  } catch (error) {
    console.error(
      "Apply Leave Error:",
      error
    );

    return res.status(500).json({
      success: false,

      message:
        "Unable to submit leave request",
    });
  }
};

// ==========================================
// EMPLOYEE - GET MY LEAVE REQUESTS
// ==========================================

const getMyLeaves = async (
  req,
  res
) => {
  try {
    const userId =
      req.user.id;

    const [leaves] =
      await pool.query(
        `
        SELECT
          id,
          leave_type,
          from_date,
          to_date,
          reason,
          status,
          admin_comment,
          created_at,
          updated_at
        FROM leave_requests
        WHERE user_id = ?
        ORDER BY created_at DESC
        `,
        [
          userId,
        ]
      );

    return res.status(200).json({
      success: true,
      leaves,
    });
  } catch (error) {
    console.error(
      "Get My Leaves Error:",
      error
    );

    return res.status(500).json({
      success: false,

      message:
        "Unable to load leave requests",
    });
  }
};

// ==========================================
// ADMIN - GET ALL LEAVE REQUESTS
// ==========================================

const getAllLeaves = async (
  req,
  res
) => {
  try {
    const [leaves] =
      await pool.query(
        `
        SELECT
          l.id,
          l.leave_type,
          l.from_date,
          l.to_date,
          l.reason,
          l.status,
          l.admin_comment,
          l.created_at,
          l.updated_at,

          u.id AS user_id,
          u.employee_id,
          u.full_name,
          u.email

        FROM leave_requests l

        INNER JOIN users u
          ON l.user_id = u.id

        WHERE
          u.role = 'employee'

        ORDER BY
          CASE
            WHEN l.status = 'pending'
              THEN 0

            WHEN l.status = 'approved'
              THEN 1

            ELSE 2
          END,

          l.created_at DESC
        `
      );

    const pending =
      leaves.filter(
        (leave) =>
          leave.status ===
          "pending"
      ).length;

    const approved =
      leaves.filter(
        (leave) =>
          leave.status ===
          "approved"
      ).length;

    const rejected =
      leaves.filter(
        (leave) =>
          leave.status ===
          "rejected"
      ).length;

    return res.status(200).json({
      success: true,

      summary: {
        total:
          leaves.length,

        pending,

        approved,

        rejected,
      },

      leaves,
    });
  } catch (error) {
    console.error(
      "Get All Leaves Error:",
      error
    );

    return res.status(500).json({
      success: false,

      message:
        "Unable to load leave requests",
    });
  }
};

// ==========================================
// ADMIN - APPROVE LEAVE
// ==========================================

const approveLeave = async (
  req,
  res
) => {
  try {
    const leaveId =
      req.params.id;

    const {
      adminComment,
    } = req.body;

    // ========================================
    // FIND LEAVE REQUEST
    // ========================================

    const [leaves] =
      await pool.query(
        `
        SELECT
          id,
          user_id,
          leave_type,
          from_date,
          to_date,
          status
        FROM leave_requests
        WHERE id = ?
        LIMIT 1
        `,
        [
          leaveId,
        ]
      );

    if (
      leaves.length === 0
    ) {
      return res.status(404).json({
        success: false,

        message:
          "Leave request not found",
      });
    }

    const leave =
      leaves[0];

    if (
      leave.status !==
      "pending"
    ) {
      return res.status(400).json({
        success: false,

        message:
          "Only pending leave requests can be approved",
      });
    }

    // ========================================
    // UPDATE LEAVE STATUS
    // ========================================

    await pool.query(
      `
      UPDATE leave_requests
      SET
        status = 'approved',
        admin_comment = ?
      WHERE id = ?
      `,
      [
        adminComment?.trim() ||
          null,

        leaveId,
      ]
    );

    // ========================================
    // CREATE EMPLOYEE NOTIFICATION
    // ========================================

    const notificationMessage =
      adminComment?.trim()
        ? `Your ${leave.leave_type} leave request has been approved. Admin comment: ${adminComment.trim()}`
        : `Your ${leave.leave_type} leave request has been approved.`;

    await pool.query(
      `
      INSERT INTO notifications
      (
        user_id,
        title,
        message,
        type,
        is_read
      )
      VALUES
      (
        ?,
        ?,
        ?,
        ?,
        FALSE
      )
      `,
      [
        leave.user_id,
        "Leave Request Approved",
        notificationMessage,
        "leave_approved",
      ]
    );

    return res.status(200).json({
      success: true,

      message:
        "Leave request approved and employee notified",
    });
  } catch (error) {
    console.error(
      "Approve Leave Error:",
      error
    );

    return res.status(500).json({
      success: false,

      message:
        "Unable to approve leave request",
    });
  }
};

// ==========================================
// ADMIN - REJECT LEAVE
// ==========================================

const rejectLeave = async (
  req,
  res
) => {
  try {
    const leaveId =
      req.params.id;

    const {
      adminComment,
    } = req.body;

    // ========================================
    // FIND LEAVE REQUEST
    // ========================================

    const [leaves] =
      await pool.query(
        `
        SELECT
          id,
          user_id,
          leave_type,
          from_date,
          to_date,
          status
        FROM leave_requests
        WHERE id = ?
        LIMIT 1
        `,
        [
          leaveId,
        ]
      );

    if (
      leaves.length === 0
    ) {
      return res.status(404).json({
        success: false,

        message:
          "Leave request not found",
      });
    }

    const leave =
      leaves[0];

    if (
      leave.status !==
      "pending"
    ) {
      return res.status(400).json({
        success: false,

        message:
          "Only pending leave requests can be rejected",
      });
    }

    // ========================================
    // UPDATE LEAVE STATUS
    // ========================================

    await pool.query(
      `
      UPDATE leave_requests
      SET
        status = 'rejected',
        admin_comment = ?
      WHERE id = ?
      `,
      [
        adminComment?.trim() ||
          null,

        leaveId,
      ]
    );

    // ========================================
    // CREATE EMPLOYEE NOTIFICATION
    // ========================================

    const notificationMessage =
      adminComment?.trim()
        ? `Your ${leave.leave_type} leave request has been rejected. Admin comment: ${adminComment.trim()}`
        : `Your ${leave.leave_type} leave request has been rejected.`;

    await pool.query(
      `
      INSERT INTO notifications
      (
        user_id,
        title,
        message,
        type,
        is_read
      )
      VALUES
      (
        ?,
        ?,
        ?,
        ?,
        FALSE
      )
      `,
      [
        leave.user_id,
        "Leave Request Rejected",
        notificationMessage,
        "leave_rejected",
      ]
    );

    return res.status(200).json({
      success: true,

      message:
        "Leave request rejected and employee notified",
    });
  } catch (error) {
    console.error(
      "Reject Leave Error:",
      error
    );

    return res.status(500).json({
      success: false,

      message:
        "Unable to reject leave request",
    });
  }
};

// ==========================================
// EXPORT CONTROLLERS
// ==========================================

module.exports = {
  applyLeave,
  getMyLeaves,
  getAllLeaves,
  approveLeave,
  rejectLeave,
};