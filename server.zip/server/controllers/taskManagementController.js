const {
    getActiveEmployees,
    getAllTasks,
    createTask: createTaskService
} = require("../services/taskService");

// ========================================
// GET ALL EMPLOYEES
// ========================================

const getEmployees = async (req, res) => {

    try {

        const employees = await getActiveEmployees();

        return res.json({
            success: true,
            employees
        });

    } catch (error) {

        console.error(error);

        return res.status(500).json({
            success: false,
            message: "Unable to fetch employees"
        });

    }

};

// ========================================
// GET ALL TASKS
// ========================================

const getTasks = async (req, res) => {

    try {

        const tasks = await getAllTasks();

        return res.json({
            success: true,
            tasks
        });

    } catch (error) {

        console.error(error);

        return res.status(500).json({
            success: false,
            message: "Unable to fetch tasks"
        });

    }

};

// ========================================
// CREATE TASK
// ========================================

const createTask = async (req, res) => {

    try {

        await createTaskService({

            ...req.body,

            assigned_by: req.user.id

        });

        return res.json({

            success: true,

            message: "Task created successfully"

        });

    } catch (error) {

        console.error(error);

        return res.status(500).json({

            success: false,

            message: "Unable to create task"

        });

    }

};

module.exports = {

    getEmployees,

    getTasks,

    createTask

};