const pool = require("../config/db");

// ==========================================
// EMPLOYEE - CREATE / START TASK
// ==========================================

const createTask = async (req, res) => {
  try {
    const userId = req.user.id;

    const {
      taskTitle,
      taskDescription,
    } = req.body;

    if (
      !taskTitle?.trim() ||
      !taskDescription?.trim()
    ) {
      return res.status(400).json({
        success: false,
        message:
          "Task title and description are required",
      });
    }

    // Check if employee already has
    // an active task
    const [activeTasks] =
      await pool.query(
        `
        SELECT id
        FROM tasks
        WHERE user_id = ?
        AND status = 'in_progress'
        LIMIT 1
        `,
        [userId]
      );

    if (activeTasks.length > 0) {
      return res.status(400).json({
        success: false,
        message:
          "Complete your current task before starting a new task",
      });
    }

    const [result] =
      await pool.query(
        `
        INSERT INTO tasks
        (
          user_id,
          task_title,
          task_description,
          status,
          start_time
        )
        VALUES
        (
          ?,
          ?,
          ?,
          'in_progress',
          NOW(6)
        )
        `,
        [
          userId,
          taskTitle.trim(),
          taskDescription.trim(),
        ]
      );

    const [newTask] =
      await pool.query(
        `
        SELECT *
        FROM tasks
        WHERE id = ?
        `,
        [result.insertId]
      );

    return res.status(201).json({
      success: true,
      message:
        "Task started successfully",
      task: newTask[0],
    });

  } catch (error) {
    console.error(
      "Create Task Error:",
      error
    );

    return res.status(500).json({
      success: false,
      message:
        "Unable to start task",
    });
  }
};

// ==========================================
// EMPLOYEE - GET MY TASKS
// ==========================================

const getMyTasks = async (
  req,
  res
) => {
  try {
    const userId = req.user.id;

    const [tasks] =
      await pool.query(
        `
        SELECT
          id,
          task_title,
          task_description,
          status,
          start_time,
          completed_time,
          created_at,
          updated_at

        FROM tasks

        WHERE user_id = ?

        ORDER BY
          CASE
            WHEN status = 'in_progress'
            THEN 0
            ELSE 1
          END,
          created_at DESC
        `,
        [userId]
      );

    return res.status(200).json({
      success: true,
      tasks,
    });

  } catch (error) {
    console.error(
      "Get My Tasks Error:",
      error
    );

    return res.status(500).json({
      success: false,
      message:
        "Unable to load tasks",
    });
  }
};

// ==========================================
// EMPLOYEE - UPDATE TASK DESCRIPTION
// ==========================================

const updateTask = async (
  req,
  res
) => {
  try {
    const userId = req.user.id;

    const taskId =
      req.params.id;

    const {
      taskTitle,
      taskDescription,
    } = req.body;

    const [tasks] =
      await pool.query(
        `
        SELECT *
        FROM tasks
        WHERE id = ?
        AND user_id = ?
        LIMIT 1
        `,
        [
          taskId,
          userId,
        ]
      );

    if (tasks.length === 0) {
      return res.status(404).json({
        success: false,
        message:
          "Task not found",
      });
    }

    if (
      tasks[0].status ===
      "completed"
    ) {
      return res.status(400).json({
        success: false,
        message:
          "Completed tasks cannot be updated",
      });
    }

    const updatedTitle =
      taskTitle?.trim() ||
      tasks[0].task_title;

    const updatedDescription =
      taskDescription?.trim() ||
      tasks[0].task_description;

    await pool.query(
      `
      UPDATE tasks
      SET
        task_title = ?,
        task_description = ?
      WHERE id = ?
      AND user_id = ?
      `,
      [
        updatedTitle,
        updatedDescription,
        taskId,
        userId,
      ]
    );

    return res.status(200).json({
      success: true,
      message:
        "Task updated successfully",
    });

  } catch (error) {
    console.error(
      "Update Task Error:",
      error
    );

    return res.status(500).json({
      success: false,
      message:
        "Unable to update task",
    });
  }
};

// ==========================================
// EMPLOYEE - COMPLETE TASK
// ==========================================

const completeTask = async (
  req,
  res
) => {
  try {
    const userId = req.user.id;

    const taskId =
      req.params.id;

    const [tasks] =
      await pool.query(
        `
        SELECT *
        FROM tasks
        WHERE id = ?
        AND user_id = ?
        LIMIT 1
        `,
        [
          taskId,
          userId,
        ]
      );

    if (tasks.length === 0) {
      return res.status(404).json({
        success: false,
        message:
          "Task not found",
      });
    }

    if (
      tasks[0].status ===
      "completed"
    ) {
      return res.status(400).json({
        success: false,
        message:
          "Task is already completed",
      });
    }

    await pool.query(
      `
      UPDATE tasks

      SET
        status = 'completed',
        completed_time = NOW(6)

      WHERE id = ?
      AND user_id = ?
      `,
      [
        taskId,
        userId,
      ]
    );

    return res.status(200).json({
      success: true,
      message:
        "Task completed successfully",
    });

  } catch (error) {
    console.error(
      "Complete Task Error:",
      error
    );

    return res.status(500).json({
      success: false,
      message:
        "Unable to complete task",
    });
  }
};

// ==========================================
// ADMIN - GET ALL EMPLOYEE TASKS
// ==========================================

const getAdminTasks = async (
  req,
  res
) => {
  try {
    const [tasks] =
      await pool.query(
        `
        SELECT
          t.id,
          t.task_title,
          t.task_description,
          t.status,
          t.start_time,
          t.completed_time,
          t.created_at,

          u.id AS user_id,
          u.employee_id,
          u.full_name

        FROM tasks t

        INNER JOIN users u
          ON t.user_id = u.id

        WHERE
          u.role = 'employee'

        ORDER BY
          CASE
            WHEN t.status =
              'in_progress'
            THEN 0
            ELSE 1
          END,
          t.created_at DESC
        `
      );

    const inProgress =
      tasks.filter(
        (task) =>
          task.status ===
          "in_progress"
      ).length;

    const completed =
      tasks.filter(
        (task) =>
          task.status ===
          "completed"
      ).length;

    return res.status(200).json({
      success: true,

      summary: {
        totalTasks:
          tasks.length,

        inProgress,

        completed,
      },

      tasks,
    });

  } catch (error) {
    console.error(
      "Admin Tasks Error:",
      error
    );

    return res.status(500).json({
      success: false,
      message:
        "Unable to load employee tasks",
    });
  }
};

module.exports = {
  createTask,
  getMyTasks,
  updateTask,
  completeTask,
  getAdminTasks,
};