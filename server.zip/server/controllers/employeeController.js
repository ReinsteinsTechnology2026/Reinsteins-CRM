const bcrypt = require("bcrypt");
const pool = require("../config/db");
const fs = require("fs");
const path = require("path");

// ==========================================
// GET ALL EMPLOYEES - ADMIN
// ==========================================

const getEmployees = async (req, res) => {
  try {
    const [employees] = await pool.query(
      `
      SELECT
        id,
        employee_id,
        first_name,
        last_name,
        full_name,
        email,
        phone,
        address,
        date_of_birth,
        designation,
        emergency_contact,
        profile_photo,
        role,
        status,
        last_login,
        created_at
      FROM users
      WHERE role = 'employee'
      ORDER BY
        CASE
          WHEN status = 'pending' THEN 1
          WHEN status = 'active' THEN 2
          ELSE 3
        END,
        created_at DESC
      `
    );

    return res.status(200).json({
      success: true,
      employees,
    });
  } catch (error) {
    console.error(
      "Get Employees Error:",
      error
    );

    return res.status(500).json({
      success: false,
      message:
        "Unable to load employees",
    });
  }
};

// ==========================================
// ADMIN CREATE EMPLOYEE
// ==========================================

const createEmployee = async (req, res) => {
  try {
    const {
      employeeId,
      fullName,
      email,
      password,
    } = req.body;

    if (
      !employeeId?.trim() ||
      !fullName?.trim() ||
      !password
    ) {
      return res.status(400).json({
        success: false,
        message:
          "Employee ID, name and password are required",
      });
    }

    const cleanedEmployeeId =
      employeeId.trim();

    const cleanedEmail =
      email?.trim().toLowerCase() ||
      null;

    // ======================================
    // VALIDATE EMAIL
    // ======================================

    if (cleanedEmail) {
      const emailPattern =
        /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

      if (
        !emailPattern.test(
          cleanedEmail
        )
      ) {
        return res.status(400).json({
          success: false,
          message:
            "Please enter a valid email address",
        });
      }
    }

    // ======================================
    // CHECK EMPLOYEE ID
    // ======================================

    const [existingEmployeeId] =
      await pool.query(
        `
        SELECT id
        FROM users
        WHERE employee_id = ?
        LIMIT 1
        `,
        [cleanedEmployeeId]
      );

    if (
      existingEmployeeId.length > 0
    ) {
      return res.status(409).json({
        success: false,
        message:
          "Employee ID already exists",
      });
    }

    // ======================================
    // CHECK EMAIL
    // ======================================

    if (cleanedEmail) {
      const [existingEmail] =
        await pool.query(
          `
          SELECT id
          FROM users
          WHERE LOWER(email) = ?
          LIMIT 1
          `,
          [cleanedEmail]
        );

      if (
        existingEmail.length > 0
      ) {
        return res.status(409).json({
          success: false,
          message:
            "Email address already exists",
        });
      }
    }

    // ======================================
    // HASH PASSWORD
    // ======================================

    const hashedPassword =
      await bcrypt.hash(
        password,
        12
      );

    // ======================================
    // CREATE EMPLOYEE
    // ======================================

    const [result] =
      await pool.query(
        `
        INSERT INTO users
        (
          employee_id,
          full_name,
          email,
          password,
          role,
          status
        )
        VALUES
        (
          ?,
          ?,
          ?,
          ?,
          'employee',
          'active'
        )
        `,
        [
          cleanedEmployeeId,
          fullName.trim(),
          cleanedEmail,
          hashedPassword,
        ]
      );

    return res.status(201).json({
      success: true,
      message:
        "Employee created successfully",
      id: result.insertId,
    });
  } catch (error) {
    console.error(
      "Create Employee Error:",
      error
    );

    return res.status(500).json({
      success: false,
      message:
        "Unable to create employee",
    });
  }
};

// ==========================================
// ADMIN UPDATE EMPLOYEE
// ==========================================

const updateEmployee = async (req, res) => {
  try {
    const { id } =
      req.params;

    const {
      fullName,
      email,
    } = req.body;

    if (
      !fullName?.trim()
    ) {
      return res.status(400).json({
        success: false,
        message:
          "Employee name is required",
      });
    }

    const cleanedEmail =
      email?.trim().toLowerCase() ||
      null;

    // ======================================
    // VALIDATE EMAIL
    // ======================================

    if (cleanedEmail) {
      const emailPattern =
        /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

      if (
        !emailPattern.test(
          cleanedEmail
        )
      ) {
        return res.status(400).json({
          success: false,
          message:
            "Please enter a valid email address",
        });
      }

      // ====================================
      // CHECK DUPLICATE EMAIL
      // ====================================

      const [duplicateEmail] =
        await pool.query(
          `
          SELECT id
          FROM users
          WHERE LOWER(email) = ?
          AND id != ?
          LIMIT 1
          `,
          [
            cleanedEmail,
            id,
          ]
        );

      if (
        duplicateEmail.length > 0
      ) {
        return res.status(409).json({
          success: false,
          message:
            "Email address already exists",
        });
      }
    }

    // ======================================
    // UPDATE EMPLOYEE
    // ======================================

    const [result] =
      await pool.query(
        `
        UPDATE users
        SET
          full_name = ?,
          email = ?
        WHERE id = ?
        AND role = 'employee'
        `,
        [
          fullName.trim(),
          cleanedEmail,
          id,
        ]
      );

    if (
      result.affectedRows === 0
    ) {
      return res.status(404).json({
        success: false,
        message:
          "Employee not found",
      });
    }

    return res.status(200).json({
      success: true,
      message:
        "Employee updated successfully",
    });
  } catch (error) {
    console.error(
      "Update Employee Error:",
      error
    );

    return res.status(500).json({
      success: false,
      message:
        "Unable to update employee",
    });
  }
};

// ==========================================
// CHANGE EMPLOYEE STATUS - ADMIN
// ==========================================

const changeEmployeeStatus =
  async (req, res) => {
    try {
      const { id } =
        req.params;

      const { status } =
        req.body;

      if (
        ![
          "pending",
          "active",
          "inactive",
        ].includes(status)
      ) {
        return res.status(400).json({
          success: false,
          message:
            "Invalid employee status",
        });
      }

      const [result] =
        await pool.query(
          `
          UPDATE users
          SET status = ?
          WHERE id = ?
          AND role = 'employee'
          `,
          [
            status,
            id,
          ]
        );

      if (
        result.affectedRows === 0
      ) {
        return res.status(404).json({
          success: false,
          message:
            "Employee not found",
        });
      }

      let message =
        "Employee status updated";

      if (
        status === "active"
      ) {
        message =
          "Employee approved and activated successfully";
      }

      if (
        status === "inactive"
      ) {
        message =
          "Employee deactivated successfully";
      }

      return res.status(200).json({
        success: true,
        message,
      });
    } catch (error) {
      console.error(
        "Employee Status Error:",
        error
      );

      return res.status(500).json({
        success: false,
        message:
          "Unable to update employee status",
      });
    }
  };

// ==========================================
// GET MY PROFILE - EMPLOYEE
// ==========================================

const getMyProfile =
  async (req, res) => {
    try {
      const userId =
        req.user.id;

      const [users] =
        await pool.query(
          `
          SELECT
            id,
            employee_id,
            first_name,
            last_name,
            full_name,
            email,
            phone,
            address,
            date_of_birth,
            designation,
            emergency_contact,
            profile_photo,
            role,
            status,
            last_login,
            created_at,
            updated_at
          FROM users
          WHERE id = ?
          AND role = 'employee'
          LIMIT 1
          `,
          [userId]
        );

      if (
        users.length === 0
      ) {
        return res.status(404).json({
          success: false,
          message:
            "Employee profile not found",
        });
      }

      return res.status(200).json({
        success: true,
        profile:
          users[0],
      });
    } catch (error) {
      console.error(
        "Get My Profile Error:",
        error
      );

      return res.status(500).json({
        success: false,
        message:
          "Unable to load profile",
      });
    }
  };

// ==========================================
// UPDATE MY PROFILE - EMPLOYEE
// ==========================================

const updateMyProfile =
  async (req, res) => {
    try {
      const userId =
        req.user.id;

      const {
        fullName,
        email,
        phone,
        address,
        dateOfBirth,
        designation,
        emergencyContact,
      } = req.body;

      // ====================================
      // VALIDATE FULL NAME
      // ====================================

      if (
        !fullName?.trim()
      ) {
        return res.status(400).json({
          success: false,
          message:
            "Full name is required",
        });
      }

      // ====================================
      // CLEAN EMAIL
      // ====================================

      const cleanedEmail =
        email?.trim().toLowerCase() ||
        null;

      // ====================================
      // VALIDATE EMAIL
      // ====================================

      if (cleanedEmail) {
        const emailPattern =
          /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

        if (
          !emailPattern.test(
            cleanedEmail
          )
        ) {
          return res.status(400).json({
            success: false,
            message:
              "Please enter a valid email address",
          });
        }

        // ==================================
        // CHECK DUPLICATE EMAIL
        // ==================================

        const [existingEmail] =
          await pool.query(
            `
            SELECT id
            FROM users
            WHERE LOWER(email) = ?
            AND id != ?
            LIMIT 1
            `,
            [
              cleanedEmail,
              userId,
            ]
          );

        if (
          existingEmail.length > 0
        ) {
          return res.status(409).json({
            success: false,
            message:
              "This email address is already used by another account",
          });
        }
      }

      // ====================================
      // UPDATE PROFILE
      // ====================================

      const [result] =
        await pool.query(
          `
          UPDATE users
          SET
            full_name = ?,
            email = ?,
            phone = ?,
            address = ?,
            date_of_birth = ?,
            designation = ?,
            emergency_contact = ?
          WHERE id = ?
          AND role = 'employee'
          `,
          [
            fullName.trim(),
            cleanedEmail,
            phone?.trim() ||
              null,
            address?.trim() ||
              null,
            dateOfBirth ||
              null,
            designation?.trim() ||
              null,
            emergencyContact?.trim() ||
              null,
            userId,
          ]
        );

      if (
        result.affectedRows === 0
      ) {
        return res.status(404).json({
          success: false,
          message:
            "Employee profile not found",
        });
      }

      // ====================================
      // GET UPDATED PROFILE
      // ====================================

      const [updatedProfile] =
        await pool.query(
          `
          SELECT
            id,
            employee_id,
            first_name,
            last_name,
            full_name,
            email,
            phone,
            address,
            date_of_birth,
            designation,
            emergency_contact,
            profile_photo,
            role,
            status,
            last_login,
            created_at,
            updated_at
          FROM users
          WHERE id = ?
          AND role = 'employee'
          LIMIT 1
          `,
          [userId]
        );

      return res.status(200).json({
        success: true,
        message:
          "Profile updated successfully",
        profile:
          updatedProfile[0],
      });
    } catch (error) {
      console.error(
        "Update My Profile Error:",
        error
      );

      return res.status(500).json({
        success: false,
        message:
          "Unable to update profile",
      });
    }
  };

// ==========================================
// UPLOAD PROFILE PHOTO - EMPLOYEE
// ==========================================

const uploadMyProfilePhoto =
  async (req, res) => {
    try {
      const userId =
        req.user.id;

      // ====================================
      // CHECK UPLOADED FILE
      // ====================================

      if (!req.file) {
        return res.status(400).json({
          success: false,
          message:
            "Please select a profile photo",
        });
      }

      // ====================================
      // GET EXISTING PROFILE PHOTO
      // ====================================

      const [users] =
        await pool.query(
          `
          SELECT
            profile_photo
          FROM users
          WHERE id = ?
          AND role = 'employee'
          LIMIT 1
          `,
          [userId]
        );

      if (
        users.length === 0
      ) {
        if (
          fs.existsSync(
            req.file.path
          )
        ) {
          fs.unlinkSync(
            req.file.path
          );
        }

        return res.status(404).json({
          success: false,
          message:
            "Employee profile not found",
        });
      }

      const oldProfilePhoto =
        users[0].profile_photo;

      // ====================================
      // SAVE PHOTO URL
      // ====================================

      const profilePhoto =
        `/uploads/profiles/${req.file.filename}`;

      await pool.query(
        `
        UPDATE users
        SET profile_photo = ?
        WHERE id = ?
        AND role = 'employee'
        `,
        [
          profilePhoto,
          userId,
        ]
      );

      // ====================================
      // DELETE OLD PROFILE PHOTO
      // ====================================

      if (
        oldProfilePhoto
      ) {
        const oldFileName =
          path.basename(
            oldProfilePhoto
          );

        const oldPhotoPath =
          path.join(
            __dirname,
            "../uploads/profiles",
            oldFileName
          );

        if (
          fs.existsSync(
            oldPhotoPath
          )
        ) {
          try {
            fs.unlinkSync(
              oldPhotoPath
            );
          } catch (
            deleteError
          ) {
            console.error(
              "Unable to delete old profile photo:",
              deleteError
            );
          }
        }
      }

      // ====================================
      // GET UPDATED PROFILE
      // ====================================

      const [updatedProfile] =
        await pool.query(
          `
          SELECT
            id,
            employee_id,
            full_name,
            email,
            phone,
            address,
            date_of_birth,
            designation,
            emergency_contact,
            profile_photo,
            role,
            status
          FROM users
          WHERE id = ?
          AND role = 'employee'
          LIMIT 1
          `,
          [userId]
        );

      return res.status(200).json({
        success: true,
        message:
          "Profile photo updated successfully",
        profilePhoto,
        profile:
          updatedProfile[0],
      });
    } catch (error) {
      console.error(
        "Upload Profile Photo Error:",
        error
      );

      // ====================================
      // REMOVE FAILED UPLOAD
      // ====================================

      if (
        req.file?.path &&
        fs.existsSync(
          req.file.path
        )
      ) {
        try {
          fs.unlinkSync(
            req.file.path
          );
        } catch (
          deleteError
        ) {
          console.error(
            "Unable to remove failed upload:",
            deleteError
          );
        }
      }

      return res.status(500).json({
        success: false,
        message:
          "Unable to upload profile photo",
      });
    }
  };

// ==========================================
// EXPORTS
// ==========================================

module.exports = {
  getEmployees,
  createEmployee,
  updateEmployee,
  changeEmployeeStatus,
  getMyProfile,
  updateMyProfile,
  uploadMyProfilePhoto,
};