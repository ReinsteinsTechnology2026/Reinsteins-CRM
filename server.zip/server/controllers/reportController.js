const pool = require("../config/db");
const ExcelJS = require("exceljs");

// ==========================================
// EMPLOYEE REPORT
// ==========================================

const getEmployeeReport = async (req, res) => {
  try {
    const [employees] = await pool.query(
      `SELECT
        id,
        employee_id,
        full_name,
        email,
        phone,
        designation,
        date_of_birth,
        emergency_contact,
        address,
        profile_photo,
        status,
        last_login,
        created_at
       FROM users
       WHERE role = 'employee'
       ORDER BY full_name ASC`
    );

    return res.status(200).json({
      success: true,
      reportType: "employees",
      count: employees.length,
      data: employees,
    });
  } catch (error) {
    console.error(
      "Employee Report Error:",
      error
    );

    return res.status(500).json({
      success: false,
      message: "Unable to load employee report",
    });
  }
};

// ==========================================
// ATTENDANCE REPORT
// ==========================================

const getAttendanceReport = async (req, res) => {
  try {
    const {
      employeeId,
      fromDate,
      toDate,
    } = req.query;

    let query = `
      SELECT
        a.id,
        u.employee_id,
        u.full_name,
        u.profile_photo,
        u.email,
        u.designation,
        a.login_time,
        a.logout_time,
        a.work_duration_seconds,
        a.total_break_seconds,
        a.status,
        a.created_at
      FROM attendance a
      INNER JOIN users u
        ON a.user_id = u.id
      WHERE u.role = 'employee'
    `;

    const values = [];

    if (employeeId) {
      query += `
        AND u.employee_id = ?
      `;

      values.push(employeeId);
    }

    if (fromDate) {
      query += `
        AND DATE(a.login_time) >= ?
      `;

      values.push(fromDate);
    }

    if (toDate) {
      query += `
        AND DATE(a.login_time) <= ?
      `;

      values.push(toDate);
    }

    query += `
      ORDER BY a.login_time ASC
    `;

    const [attendance] =
      await pool.query(
        query,
        values
      );

    let totalWorkSeconds = 0;
    let totalBreakSeconds = 0;

    attendance.forEach((record) => {
      totalWorkSeconds +=
        Number(
          record.work_duration_seconds || 0
        );

      totalBreakSeconds +=
        Number(
          record.total_break_seconds || 0
        );
    });

    const attendanceRecords =
      attendance.length;

    const averageWorkSeconds =
      attendanceRecords > 0
        ? Math.round(
            totalWorkSeconds /
              attendanceRecords
          )
        : 0;

    return res.status(200).json({
      success: true,

      reportType:
        "attendance",

      employeeId:
        employeeId || null,

      count:
        attendanceRecords,

      summary: {
        attendanceRecords,
        totalWorkSeconds,
        totalBreakSeconds,
        averageWorkSeconds,
      },

      data:
        attendance,
    });
  } catch (error) {
    console.error(
      "Attendance Report Error:",
      error
    );

    return res.status(500).json({
      success: false,
      message:
        "Unable to load attendance report",
    });
  }
};

// ==========================================
// TASK REPORT
// ==========================================

const getTaskReport = async (req, res) => {
  try {
    const {
      employeeId,
      fromDate,
      toDate,
    } = req.query;

    let query = `
      SELECT
        t.id,
        u.employee_id,
        u.full_name,
        u.profile_photo,
        u.email,
        u.designation,
        t.task_title,
        t.task_description,
        t.status,
        t.start_time,
        t.completed_time,
        t.created_at,
        t.updated_at
      FROM tasks t
      INNER JOIN users u
        ON t.user_id = u.id
      WHERE u.role = 'employee'
    `;

    const values = [];

    if (employeeId) {
      query += `
        AND u.employee_id = ?
      `;

      values.push(employeeId);
    }

    if (fromDate) {
      query += `
        AND DATE(t.created_at) >= ?
      `;

      values.push(fromDate);
    }

    if (toDate) {
      query += `
        AND DATE(t.created_at) <= ?
      `;

      values.push(toDate);
    }

    query += `
      ORDER BY t.created_at DESC
    `;

    const [tasks] =
      await pool.query(
        query,
        values
      );

    const totalTasks =
      tasks.length;

    const completedTasks =
      tasks.filter(
        (task) =>
          String(
            task.status
          ).toLowerCase() ===
          "completed"
      ).length;

    const inProgressTasks =
      tasks.filter((task) => {
        const status =
          String(
            task.status || ""
          )
            .toLowerCase()
            .replace(
              /[-\s]/g,
              "_"
            );

        return (
          status === "in_progress" ||
          status === "progress"
        );
      }).length;

    return res.status(200).json({
      success: true,

      reportType:
        "tasks",

      employeeId:
        employeeId || null,

      count:
        totalTasks,

      summary: {
        totalTasks,
        completedTasks,
        inProgressTasks,
      },

      data:
        tasks,
    });
  } catch (error) {
    console.error(
      "Task Report Error:",
      error
    );

    return res.status(500).json({
      success: false,
      message:
        "Unable to load task report",
    });
  }
};

// ==========================================
// LEAVE REPORT
// ==========================================

const getLeaveReport = async (req, res) => {
  try {
    const {
      employeeId,
      fromDate,
      toDate,
    } = req.query;

    let query = `
      SELECT
        l.id,
        u.employee_id,
        u.full_name,
        u.profile_photo,
        u.email,
        u.designation,
        l.leave_type,
        l.from_date,
        l.to_date,
        l.reason,
        l.status,
        l.admin_comment,
        l.created_at,
        l.updated_at
      FROM leave_requests l
      INNER JOIN users u
        ON l.user_id = u.id
      WHERE u.role = 'employee'
    `;

    const values = [];

    if (employeeId) {
      query += `
        AND u.employee_id = ?
      `;

      values.push(employeeId);
    }

    if (fromDate) {
      query += `
        AND DATE(l.to_date) >= ?
      `;

      values.push(fromDate);
    }

    if (toDate) {
      query += `
        AND DATE(l.from_date) <= ?
      `;

      values.push(toDate);
    }

    query += `
      ORDER BY
        l.from_date DESC,
        l.created_at DESC
    `;

    const [leaves] =
      await pool.query(
        query,
        values
      );

    const totalRequests =
      leaves.length;

    const pendingRequests =
      leaves.filter(
        (leave) =>
          String(
            leave.status
          ).toLowerCase() ===
          "pending"
      ).length;

    const approvedRequests =
      leaves.filter(
        (leave) =>
          String(
            leave.status
          ).toLowerCase() ===
          "approved"
      ).length;

    const rejectedRequests =
      leaves.filter(
        (leave) =>
          String(
            leave.status
          ).toLowerCase() ===
          "rejected"
      ).length;

    return res.status(200).json({
      success: true,

      reportType:
        "leave",

      employeeId:
        employeeId || null,

      count:
        totalRequests,

      summary: {
        totalRequests,
        pendingRequests,
        approvedRequests,
        rejectedRequests,
      },

      data:
        leaves,
    });
  } catch (error) {
    console.error(
      "Leave Report Error:",
      error
    );

    return res.status(500).json({
      success: false,
      message:
        "Unable to load leave report",
    });
  }
};

// ==========================================
// FORMAT EXCEL DATE
// ==========================================

const formatExcelDate = (value) => {
  if (!value) {
    return "";
  }

  const date =
    new Date(value);

  if (
    Number.isNaN(
      date.getTime()
    )
  ) {
    return "";
  }

  return date.toLocaleDateString(
    "en-IN"
  );
};

// ==========================================
// FORMAT EXCEL TIME
// ==========================================

const formatExcelTime = (value) => {
  if (!value) {
    return "";
  }

  const date =
    new Date(value);

  if (
    Number.isNaN(
      date.getTime()
    )
  ) {
    return "";
  }

  return date.toLocaleTimeString(
    "en-IN",
    {
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
    }
  );
};

// ==========================================
// FORMAT EXCEL DATE TIME
// ==========================================

const formatExcelDateTime = (value) => {
  if (!value) {
    return "";
  }

  const date =
    new Date(value);

  if (
    Number.isNaN(
      date.getTime()
    )
  ) {
    return "";
  }

  return date.toLocaleString(
    "en-IN"
  );
};

// ==========================================
// FORMAT WORKING DURATION
// ==========================================

const formatDuration = (seconds) => {
  const value =
    Number(seconds) || 0;

  const hours =
    Math.floor(
      value / 3600
    );

  const minutes =
    Math.floor(
      (value % 3600) / 60
    );

  const secs =
    Math.floor(
      value % 60
    );

  return `${hours}h ${minutes}m ${secs}s`;
};

// ==========================================
// EXPORT REPORT TO EXCEL
// ==========================================

const exportReportExcel = async (
  req,
  res
) => {
  try {
    const {
      reportType,
    } = req.params;

    const {
      employeeId,
      fromDate,
      toDate,
    } = req.query;

    const allowedReports = [
      "attendance",
      "tasks",
      "leave",
      "employees",
    ];

    if (
      !allowedReports.includes(
        reportType
      )
    ) {
      return res.status(400).json({
        success: false,
        message:
          "Invalid report type",
      });
    }

    const workbook =
      new ExcelJS.Workbook();

    workbook.creator =
      "Reinsteins Technology";

    workbook.created =
      new Date();

    let worksheet;

    // ========================================
    // ATTENDANCE EXCEL REPORT
    // ONE ROW PER EMPLOYEE PER DAY
    // ========================================

    if (
      reportType ===
      "attendance"
    ) {
      let query = `
        SELECT
          u.employee_id,
          u.full_name,
          u.designation,

          DATE(a.login_time)
            AS attendance_date,

          MIN(a.login_time)
            AS first_login,

          MAX(a.logout_time)
            AS last_logout,

          SUM(
            COALESCE(
              a.work_duration_seconds,
              0
            )
          ) AS total_work_seconds

        FROM attendance a

        INNER JOIN users u
          ON a.user_id = u.id

        WHERE
          u.role = 'employee'
      `;

      const values = [];

      // ======================================
      // EMPLOYEE FILTER
      // ======================================

      if (employeeId) {
        query += `
          AND u.employee_id = ?
        `;

        values.push(
          employeeId
        );
      }

      // ======================================
      // FROM DATE FILTER
      // ======================================

      if (fromDate) {
        query += `
          AND DATE(a.login_time) >= ?
        `;

        values.push(
          fromDate
        );
      }

      // ======================================
      // TO DATE FILTER
      // ======================================

      if (toDate) {
        query += `
          AND DATE(a.login_time) <= ?
        `;

        values.push(
          toDate
        );
      }

      // ======================================
      // GROUP BY EMPLOYEE + DATE
      // ======================================

      query += `
        GROUP BY
          u.employee_id,
          u.full_name,
          u.designation,
          DATE(a.login_time)

        ORDER BY
          attendance_date DESC,
          u.full_name ASC
      `;

      const [rows] =
        await pool.query(
          query,
          values
        );

      worksheet =
        workbook.addWorksheet(
          "Attendance Report"
        );

      worksheet.columns = [
        {
          header:
            "Employee ID",
          key:
            "employee_id",
          width: 15,
        },
        {
          header:
            "Employee Name",
          key:
            "full_name",
          width: 25,
        },
        {
          header:
            "Designation",
          key:
            "designation",
          width: 20,
        },
        {
          header:
            "Date",
          key:
            "attendance_date",
          width: 15,
        },
        {
          header:
            "First Login",
          key:
            "first_login",
          width: 18,
        },
        {
          header:
            "Last Logout",
          key:
            "last_logout",
          width: 18,
        },
        {
          header:
            "Total Working Hours",
          key:
            "total_working_hours",
          width: 22,
        },
      ];

      rows.forEach(
        (row) => {
          worksheet.addRow({
            employee_id:
              row.employee_id,

            full_name:
              row.full_name,

            designation:
              row.designation ||
              "",

            attendance_date:
              formatExcelDate(
                row.attendance_date
              ),

            first_login:
              formatExcelTime(
                row.first_login
              ),

            last_logout:
              row.last_logout
                ? formatExcelTime(
                    row.last_logout
                  )
                : "Currently Working",

            total_working_hours:
              formatDuration(
                row.total_work_seconds
              ),
          });
        }
      );
    }

    // ========================================
    // TASK EXCEL REPORT
    // ========================================

    if (
      reportType ===
      "tasks"
    ) {
      let query = `
        SELECT
          u.employee_id,
          u.full_name,
          u.designation,
          t.task_title,
          t.task_description,
          t.status,
          t.start_time,
          t.completed_time,
          t.created_at
        FROM tasks t
        INNER JOIN users u
          ON t.user_id = u.id
        WHERE u.role = 'employee'
      `;

      const values = [];

      if (employeeId) {
        query += `
          AND u.employee_id = ?
        `;

        values.push(
          employeeId
        );
      }

      if (fromDate) {
        query += `
          AND DATE(t.created_at) >= ?
        `;

        values.push(
          fromDate
        );
      }

      if (toDate) {
        query += `
          AND DATE(t.created_at) <= ?
        `;

        values.push(
          toDate
        );
      }

      query += `
        ORDER BY
          t.created_at DESC
      `;

      const [rows] =
        await pool.query(
          query,
          values
        );

      worksheet =
        workbook.addWorksheet(
          "Task Report"
        );

      worksheet.columns = [
        {
          header:
            "Employee ID",
          key:
            "employee_id",
          width: 15,
        },
        {
          header:
            "Employee Name",
          key:
            "full_name",
          width: 25,
        },
        {
          header:
            "Designation",
          key:
            "designation",
          width: 20,
        },
        {
          header:
            "Task Title",
          key:
            "task_title",
          width: 30,
        },
        {
          header:
            "Task Description",
          key:
            "task_description",
          width: 45,
        },
        {
          header:
            "Status",
          key:
            "status",
          width: 18,
        },
        {
          header:
            "Start Time",
          key:
            "start_time",
          width: 25,
        },
        {
          header:
            "Completed Time",
          key:
            "completed_time",
          width: 25,
        },
        {
          header:
            "Created Date",
          key:
            "created_at",
          width: 25,
        },
      ];

      rows.forEach(
        (row) => {
          worksheet.addRow({
            employee_id:
              row.employee_id,

            full_name:
              row.full_name,

            designation:
              row.designation ||
              "",

            task_title:
              row.task_title ||
              "",

            task_description:
              row.task_description ||
              "",

            status:
              row.status ||
              "",

            start_time:
              formatExcelDateTime(
                row.start_time
              ),

            completed_time:
              formatExcelDateTime(
                row.completed_time
              ),

            created_at:
              formatExcelDateTime(
                row.created_at
              ),
          });
        }
      );
    }

    // ========================================
    // LEAVE EXCEL REPORT
    // ========================================

    if (
      reportType ===
      "leave"
    ) {
      let query = `
        SELECT
          u.employee_id,
          u.full_name,
          u.designation,
          l.leave_type,
          l.from_date,
          l.to_date,
          l.reason,
          l.status,
          l.admin_comment,
          l.created_at
        FROM leave_requests l
        INNER JOIN users u
          ON l.user_id = u.id
        WHERE u.role = 'employee'
      `;

      const values = [];

      if (employeeId) {
        query += `
          AND u.employee_id = ?
        `;

        values.push(
          employeeId
        );
      }

      if (fromDate) {
        query += `
          AND DATE(l.to_date) >= ?
        `;

        values.push(
          fromDate
        );
      }

      if (toDate) {
        query += `
          AND DATE(l.from_date) <= ?
        `;

        values.push(
          toDate
        );
      }

      query += `
        ORDER BY
          l.from_date DESC
      `;

      const [rows] =
        await pool.query(
          query,
          values
        );

      worksheet =
        workbook.addWorksheet(
          "Leave Report"
        );

      worksheet.columns = [
        {
          header:
            "Employee ID",
          key:
            "employee_id",
          width: 15,
        },
        {
          header:
            "Employee Name",
          key:
            "full_name",
          width: 25,
        },
        {
          header:
            "Designation",
          key:
            "designation",
          width: 20,
        },
        {
          header:
            "Leave Type",
          key:
            "leave_type",
          width: 20,
        },
        {
          header:
            "From Date",
          key:
            "from_date",
          width: 15,
        },
        {
          header:
            "To Date",
          key:
            "to_date",
          width: 15,
        },
        {
          header:
            "Reason",
          key:
            "reason",
          width: 40,
        },
        {
          header:
            "Status",
          key:
            "status",
          width: 15,
        },
        {
          header:
            "Admin Comment",
          key:
            "admin_comment",
          width: 35,
        },
      ];

      rows.forEach(
        (row) => {
          worksheet.addRow({
            employee_id:
              row.employee_id,

            full_name:
              row.full_name,

            designation:
              row.designation ||
              "",

            leave_type:
              row.leave_type ||
              "",

            from_date:
              formatExcelDate(
                row.from_date
              ),

            to_date:
              formatExcelDate(
                row.to_date
              ),

            reason:
              row.reason ||
              "",

            status:
              row.status ||
              "",

            admin_comment:
              row.admin_comment ||
              "",
          });
        }
      );
    }

    // ========================================
    // EMPLOYEE EXCEL REPORT
    // ========================================

    if (
      reportType ===
      "employees"
    ) {
      const [rows] =
        await pool.query(
          `SELECT
            employee_id,
            full_name,
            email,
            phone,
            designation,
            date_of_birth,
            emergency_contact,
            address,
            status,
            last_login,
            created_at
           FROM users
           WHERE role = 'employee'
           ORDER BY full_name ASC`
        );

      worksheet =
        workbook.addWorksheet(
          "Employee Report"
        );

      worksheet.columns = [
        {
          header:
            "Employee ID",
          key:
            "employee_id",
          width: 15,
        },
        {
          header:
            "Full Name",
          key:
            "full_name",
          width: 25,
        },
        {
          header:
            "Email",
          key:
            "email",
          width: 30,
        },
        {
          header:
            "Phone",
          key:
            "phone",
          width: 18,
        },
        {
          header:
            "Designation",
          key:
            "designation",
          width: 20,
        },
        {
          header:
            "Date of Birth",
          key:
            "date_of_birth",
          width: 18,
        },
        {
          header:
            "Emergency Contact",
          key:
            "emergency_contact",
          width: 20,
        },
        {
          header:
            "Address",
          key:
            "address",
          width: 40,
        },
        {
          header:
            "Status",
          key:
            "status",
          width: 15,
        },
        {
          header:
            "Last Login",
          key:
            "last_login",
          width: 25,
        },
        {
          header:
            "Created Date",
          key:
            "created_at",
          width: 25,
        },
      ];

      rows.forEach(
        (row) => {
          worksheet.addRow({
            employee_id:
              row.employee_id,

            full_name:
              row.full_name,

            email:
              row.email || "",

            phone:
              row.phone || "",

            designation:
              row.designation || "",

            date_of_birth:
              formatExcelDate(
                row.date_of_birth
              ),

            emergency_contact:
              row.emergency_contact ||
              "",

            address:
              row.address || "",

            status:
              row.status || "",

            last_login:
              formatExcelDateTime(
                row.last_login
              ),

            created_at:
              formatExcelDateTime(
                row.created_at
              ),
          });
        }
      );
    }

    // ========================================
    // EXCEL HEADER STYLE
    // ========================================

    const headerRow =
      worksheet.getRow(1);

    headerRow.font = {
      bold: true,
      color: {
        argb:
          "FFFFFFFF",
      },
    };

    headerRow.fill = {
      type:
        "pattern",

      pattern:
        "solid",

      fgColor: {
        argb:
          "FF2563EB",
      },
    };

    headerRow.alignment = {
      vertical:
        "middle",

      horizontal:
        "center",
    };

    headerRow.height =
      25;

    // ========================================
    // STYLE ALL CELLS
    // ========================================

    worksheet.eachRow(
      (
        row,
        rowNumber
      ) => {
        row.eachCell(
          (cell) => {
            cell.alignment = {
              vertical:
                "middle",

              wrapText:
                true,
            };

            cell.border = {
              top: {
                style:
                  "thin",
              },

              left: {
                style:
                  "thin",
              },

              bottom: {
                style:
                  "thin",
              },

              right: {
                style:
                  "thin",
              },
            };
          }
        );

        if (
          rowNumber > 1
        ) {
          row.height =
            22;
        }
      }
    );

    // ========================================
    // FREEZE HEADER
    // ========================================

    worksheet.views = [
      {
        state:
          "frozen",

        ySplit:
          1,
      },
    ];

    // ========================================
    // AUTO FILTER
    // ========================================

    worksheet.autoFilter = {
      from:
        "A1",

      to: {
        row:
          1,

        column:
          worksheet.columnCount,
      },
    };

    // ========================================
    // FILE NAME
    // ========================================

    const dateStamp =
      new Date()
        .toISOString()
        .slice(
          0,
          10
        );

    const fileName =
      `${reportType}-report-${dateStamp}.xlsx`;

    // ========================================
    // RESPONSE HEADERS
    // ========================================

    res.setHeader(
      "Content-Type",
      "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    );

    res.setHeader(
      "Content-Disposition",
      `attachment; filename="${fileName}"`
    );

    // ========================================
    // SEND EXCEL FILE
    // ========================================

    await workbook.xlsx.write(
      res
    );

    res.end();
  } catch (error) {
    console.error(
      "Excel Export Error:",
      error
    );

    if (
      !res.headersSent
    ) {
      return res.status(500).json({
        success: false,
        message:
          "Unable to export Excel report",
      });
    }
  }
};

// ==========================================
// EXPORT CONTROLLERS
// ==========================================

module.exports = {
  getEmployeeReport,
  getAttendanceReport,
  getTaskReport,
  getLeaveReport,
  exportReportExcel,
};